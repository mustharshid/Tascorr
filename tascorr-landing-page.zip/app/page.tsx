import { Hero } from "@/components/hero"
import { Features } from "@/components/features"
import { HowItWorks } from "@/components/how-it-works"
import { Roles } from "@/components/roles"
import { Pricing } from "@/components/pricing"
import { TrustStrip } from "@/components/trust-strip"
import { Footer } from "@/components/footer"

export default function Page() {
  return (
    <main className="min-h-screen bg-background">
      <Hero />
      <Features />
      <HowItWorks />
      <Roles />
      <Pricing />
      <TrustStrip />
      <Footer />
    </main>
  )
}
