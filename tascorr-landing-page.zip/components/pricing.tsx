"use client"

import { Check } from "lucide-react"
import { cn } from "@/lib/utils"

type Plan = {
  name: string
  description: string
  price: string
  per?: string
  features: string[]
  cta: string
  featured?: boolean
}

const plans: Plan[] = [
  {
    name: "Free",
    description: "For small teams getting started with accountability.",
    price: "0",
    per: "/mo",
    features: ["Up to 10 employees", "Basic task tracking", "Community support"],
    cta: "Get Started",
  },
  {
    name: "Growth",
    description: "For scaling organisations that need full visibility.",
    price: "999",
    per: " MVR/mo",
    features: [
      "Up to 100 employees",
      "Managerial controls",
      "Blocker alerts",
      "Priority support",
    ],
    cta: "Get Started",
    featured: true,
  },
  {
    name: "Enterprise",
    description: "For large companies requiring complete audit trails.",
    price: "5,000",
    per: " MVR/mo",
    features: [
      "Unlimited employees",
      "Immutable trace trails",
      "Database tenant isolation",
      "Dedicated support",
    ],
    cta: "Contact Us",
  },
]

export function Pricing() {
  return (
    <section id="pricing" className="relative overflow-hidden px-6 py-24 sm:py-32">
      {/* subtle blue arc behind the section */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-x-0 top-0 flex justify-center"
      >
        <div
          className="h-[520px] w-[820px] rounded-[50%] opacity-[0.12]"
          style={{
            background: "transparent",
            boxShadow: "0 0 0 2px rgba(45,108,223,0.55), 0 0 80px 4px rgba(45,108,223,0.18)",
          }}
        />
      </div>

      <div className="relative z-10 mx-auto max-w-5xl">
        {/* heading */}
        <div className="text-center">
          <h2 className="text-balance text-4xl font-bold tracking-tight text-foreground sm:text-5xl">
            Find the{" "}
            <span style={{ color: "#2d6cdf" }}>Perfect Plan</span>{" "}
            for Your Business
          </h2>
          <p className="mx-auto mt-4 max-w-xl text-base leading-relaxed text-muted-foreground">
            Start for free, then grow with us. Flexible plans for organisations
            of all sizes.
          </p>
        </div>

        {/* cards */}
        <div className="mt-14 grid items-start gap-5 md:grid-cols-3">
          {plans.map((plan) => (
            <div
              key={plan.name}
              className={cn(
                "relative flex flex-col rounded-2xl border bg-card/60 p-7 backdrop-blur-md",
                plan.featured
                  ? "border-[#2d6cdf]/40 shadow-[0_0_60px_-10px_rgba(45,108,223,0.35)]"
                  : "border-white/8",
              )}
            >
              {plan.featured && (
                <div className="absolute -top-3.5 left-1/2 -translate-x-1/2">
                  <span className="inline-flex items-center gap-1.5 rounded-full border border-[#2d6cdf]/50 bg-[#2d6cdf]/20 px-3.5 py-1 text-xs font-semibold text-[#5b9bff]">
                    Most Popular
                  </span>
                </div>
              )}

              {/* plan name — large, like the reference */}
              <h3 className="mt-3 text-4xl font-bold tracking-tight text-foreground">
                {plan.name}
              </h3>
              <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                {plan.description}
              </p>

              {/* price */}
              <div className="mt-6 flex items-end gap-1">
                <span className="text-5xl font-bold leading-none text-foreground">
                  {plan.price === "0" ? "$0" : plan.price}
                </span>
                {plan.per && (
                  <span className="mb-1 text-sm text-muted-foreground">
                    {plan.per}
                  </span>
                )}
              </div>

              {/* divider */}
              <hr className="mt-6 border-white/10" />

              {/* features */}
              <ul className="mt-5 flex flex-col gap-3">
                {plan.features.map((f) => (
                  <li key={f} className="flex items-center gap-2.5 text-sm text-foreground/80">
                    <Check
                      className="size-4 shrink-0"
                      style={{ color: "#2d6cdf" }}
                      aria-hidden="true"
                    />
                    {f}
                  </li>
                ))}
              </ul>

              {/* CTA */}
              <a
                href="#"
                className={cn(
                  "mt-8 block rounded-xl px-5 py-3 text-center text-sm font-semibold transition-opacity hover:opacity-90",
                  plan.featured
                    ? "bg-[#2d6cdf] text-white"
                    : "border border-white/15 bg-white/5 text-foreground hover:bg-white/10",
                )}
              >
                {plan.cta}
              </a>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
