import { TascorrLogo } from "@/components/tascorr-logo"

const navLinks = [
  { label: "Features", href: "#features" },
  { label: "Pricing", href: "#pricing" },
  { label: "Sign In", href: "#" },
  { label: "Register Company", href: "#" },
]

export function Footer() {
  return (
    <footer className="border-t border-white/10 px-6 py-12">
      <div className="mx-auto flex max-w-6xl flex-col gap-10 md:flex-row md:items-start md:justify-between">
        <div className="flex flex-col gap-3">
          <div className="flex items-center gap-2.5">
            <TascorrLogo className="size-7 text-primary" />
            <span className="text-lg font-bold text-foreground">Tascorr</span>
          </div>
          <p className="max-w-xs text-sm leading-relaxed text-muted-foreground">
            Assign it. Track it. Own it. The workforce accountability layer for
            modern organizations.
          </p>
        </div>

        <nav
          aria-label="Footer"
          className="flex flex-wrap gap-x-6 gap-y-3"
        >
          {navLinks.map((link) => (
            <a
              key={link.label}
              href={link.href}
              className="text-sm text-muted-foreground transition-colors hover:text-foreground"
            >
              {link.label}
            </a>
          ))}
        </nav>

        <div className="text-sm text-muted-foreground">
          <p className="font-medium text-foreground">Contact</p>
          <a
            href="tel:+9607451198"
            className="mt-2 block transition-colors hover:text-foreground"
          >
            +960 7451198
          </a>
        </div>
      </div>

      <div className="mx-auto mt-10 max-w-6xl border-t border-white/10 pt-6">
        <p className="text-sm text-muted-foreground">
          &copy; {new Date().getFullYear()} Tascorr. All rights reserved.
        </p>
      </div>
    </footer>
  )
}
