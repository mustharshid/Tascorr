import {
  ShieldCheck,
  Lock,
  Smartphone,
  History,
  type LucideIcon,
} from "lucide-react"

type Item = {
  icon: LucideIcon
  label: string
}

const items: Item[] = [
  { icon: ShieldCheck, label: "Accountability without blame" },
  { icon: Lock, label: "Your data stays yours" },
  { icon: Smartphone, label: "Works on any device" },
  { icon: History, label: "A complete history, always" },
]

export function TrustStrip() {
  return (
    <section className="px-6 py-16">
      <div className="mx-auto grid max-w-5xl gap-8 text-center sm:grid-cols-2 lg:grid-cols-4">
        {items.map((item) => (
          <div
            key={item.label}
            className="flex flex-col items-center gap-3"
          >
            <item.icon className="size-6 text-primary" aria-hidden="true" />
            <span className="text-sm font-medium text-foreground">
              {item.label}
            </span>
          </div>
        ))}
      </div>
    </section>
  )
}
