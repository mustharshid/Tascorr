import {
  UserCheck,
  ListTree,
  Building2,
  LineChart,
  type LucideIcon,
} from "lucide-react"

type Feature = {
  icon: LucideIcon
  title: string
  description: string
}

const features: Feature[] = [
  {
    icon: UserCheck,
    title: "Smart Task Assignment",
    description:
      "Assign work across your team with full visibility into who's available, who's overloaded, and who's the right fit — before you hit assign.",
  },
  {
    icon: ListTree,
    title: "Subtasks & Dependencies",
    description:
      "Break large initiatives into trackable pieces, and set up tasks that automatically wait their turn — no more starting work out of order.",
  },
  {
    icon: Building2,
    title: "Cross-Department Collaboration",
    description:
      "Request access to assign work outside your department, with time-limited approvals and a full record of who authorized what.",
  },
  {
    icon: LineChart,
    title: "Performance & SLA Analytics",
    description:
      "See how quickly blockers get resolved, how long approvals take, and where your organization needs attention — all in one view.",
  },
]

export function Features() {
  return (
    <section id="features" className="px-6 py-20 sm:py-24">
      <div className="mx-auto max-w-5xl">
        <h2 className="text-center text-3xl font-bold tracking-tight text-foreground sm:text-4xl">
          Operational Features & Trace Trails
        </h2>

        <div className="mt-12 grid gap-5 sm:grid-cols-2">
          {features.map((feature) => (
            <div
              key={feature.title}
              className="rounded-2xl border border-white/10 bg-card p-7 backdrop-blur-sm"
            >
              <div className="flex size-11 items-center justify-center rounded-xl border border-primary/30 bg-primary/15 text-primary">
                <feature.icon className="size-5" aria-hidden="true" />
              </div>
              <h3 className="mt-5 text-xl font-semibold text-foreground">
                {feature.title}
              </h3>
              <p className="mt-3 text-pretty leading-relaxed text-muted-foreground">
                {feature.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
