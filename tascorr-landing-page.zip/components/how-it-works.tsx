const steps = [
  {
    number: "01",
    title: "Set Up Your Structure",
    description: "Define your departments, ranks, and people once.",
  },
  {
    number: "02",
    title: "Assign & Track",
    description:
      "Delegate tasks across your organization with full context.",
  },
  {
    number: "03",
    title: "See What's Happening",
    description:
      "Get a real-time picture of what's done, what's stuck, and why.",
  },
]

export function HowItWorks() {
  return (
    <section className="px-6 py-20 sm:py-24">
      <div className="mx-auto max-w-5xl">
        <h2 className="text-center text-3xl font-bold tracking-tight text-foreground sm:text-4xl">
          How It Works
        </h2>

        <div className="mt-12 grid gap-5 md:grid-cols-3">
          {steps.map((step) => (
            <div
              key={step.number}
              className="rounded-2xl border border-white/10 bg-card p-7 backdrop-blur-sm"
            >
              <span className="text-3xl font-bold text-primary">
                {step.number}
              </span>
              <h3 className="mt-4 text-lg font-semibold text-foreground">
                {step.title}
              </h3>
              <p className="mt-2 leading-relaxed text-muted-foreground">
                {step.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
