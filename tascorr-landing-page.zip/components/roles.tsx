import {
  User,
  Users,
  Building,
  Briefcase,
  Settings2,
  type LucideIcon,
} from "lucide-react"

type Role = {
  icon: LucideIcon
  name: string
  line: string
}

const roles: Role[] = [
  { icon: User, name: "Employees", line: "A simple view of what's yours to do." },
  { icon: Users, name: "Managers", line: "Live visibility into your team's work." },
  {
    icon: Building,
    name: "Department Heads",
    line: "Full control across your department.",
  },
  {
    icon: Briefcase,
    name: "Executives",
    line: "A real-time pulse on the whole organization.",
  },
  {
    icon: Settings2,
    name: "Admins",
    line: "Configure your company without writing code.",
  },
]

export function Roles() {
  return (
    <section className="px-6 py-20 sm:py-24">
      <div className="mx-auto max-w-6xl">
        <h2 className="text-center text-3xl font-bold tracking-tight text-foreground sm:text-4xl">
          Built For Every Role
        </h2>

        <div className="mt-12 grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
          {roles.map((role) => (
            <div
              key={role.name}
              className="rounded-2xl border border-white/10 bg-card p-6 backdrop-blur-sm"
            >
              <div className="flex size-10 items-center justify-center rounded-xl border border-primary/30 bg-primary/15 text-primary">
                <role.icon className="size-5" aria-hidden="true" />
              </div>
              <h3 className="mt-4 font-semibold text-foreground">
                {role.name}
              </h3>
              <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                {role.line}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
