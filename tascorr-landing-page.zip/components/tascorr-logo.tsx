export function TascorrLogo({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 48 48"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      aria-hidden="true"
      className={className}
    >
      <path
        d="M10 8h28l-6 8H28v24h-8V16h-4l-6-8Z"
        fill="#2d6cdf"
      />
      <path
        d="M30 8h8v8h-2.5l-5.5 7V8Z"
        fill="#2d6cdf"
        opacity="0.55"
      />
    </svg>
  )
}
