import { TascorrLogo } from "@/components/tascorr-logo"
import { Button } from "@/components/ui/button"

export function Hero() {
  return (
    <section className="relative overflow-hidden px-6 pt-24 pb-20 sm:pt-32 sm:pb-28">
      {/* warm/cool glow gradients */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-0 z-0"
      >
        <div
          className="absolute left-1/2 top-0 h-[460px] w-[860px] -translate-x-1/2 blur-3xl"
          style={{
            background:
              "radial-gradient(ellipse at center, rgba(180,90,40,0.35), transparent 70%)",
          }}
        />
        <div
          className="absolute left-1/2 top-44 h-[380px] w-[680px] -translate-x-1/2 blur-3xl"
          style={{
            background:
              "radial-gradient(ellipse at center, rgba(45,108,223,0.28), transparent 70%)",
          }}
        />
      </div>

      <div className="relative z-10 mx-auto flex max-w-3xl flex-col items-center text-center">
        <TascorrLogo className="size-14 text-primary" />

        <h1 className="mt-8 text-5xl font-bold tracking-tight text-foreground sm:text-6xl">
          Tascorr
        </h1>

        <p className="mt-5 text-balance text-2xl font-semibold text-foreground sm:text-3xl">
          Assign it. Track it. Own it.
        </p>

        <p className="mt-5 max-w-xl text-pretty text-base leading-relaxed text-muted-foreground sm:text-lg">
          The workforce accountability layer that maps your company hierarchy,
          tracks assignments with absolute clarity, and flags blockers
          transparently.
        </p>

        <div className="mt-9 flex items-center gap-4">
          <Button
            variant="ghost"
            size="lg"
            nativeButton={false}
            className="text-foreground hover:bg-white/5"
            render={<a href="#">Sign In</a>}
          />
          <Button
            variant="outline"
            size="lg"
            nativeButton={false}
            className="border-white/15 bg-white/5 text-foreground hover:bg-white/10"
            render={<a href="#">Register Company</a>}
          />
        </div>
      </div>
    </section>
  )
}
